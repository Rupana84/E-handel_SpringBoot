package com.e_handel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EHandelApplication {

	public static void main(String[] args) {
		SpringApplication.run(EHandelApplication.class, args);
	}

}
