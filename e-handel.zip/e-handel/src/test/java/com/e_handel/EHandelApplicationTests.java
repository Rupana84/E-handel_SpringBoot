package com.e_handel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EHandelApplicationTests {

	@Test
	void contextLoads() {
	}

}
